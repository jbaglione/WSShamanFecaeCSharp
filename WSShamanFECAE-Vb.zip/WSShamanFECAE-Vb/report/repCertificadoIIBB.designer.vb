﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Public Class repCertificadoIIBB
    Inherits DevExpress.XtraReports.UI.XtraReport

    'XtraReport overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Designer
    'It can be modified using the Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(repCertificadoIIBB))
        Me.Detail = New DevExpress.XtraReports.UI.DetailBand()
        Me.TopMargin = New DevExpress.XtraReports.UI.TopMarginBand()
        Me.BottomMargin = New DevExpress.XtraReports.UI.BottomMarginBand()
        Me.grpCertificado = New DevExpress.XtraReports.UI.GroupHeaderBand()
        Me.PORCE_RET = New DevExpress.XtraReports.UI.XRLabel()
        Me.IMP_RETEN = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel27 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel25 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel24 = New DevExpress.XtraReports.UI.XRLabel()
        Me.N_ING_BRUT = New DevExpress.XtraReports.UI.XRLabel()
        Me.N_CUIT = New DevExpress.XtraReports.UI.XRLabel()
        Me.NOM_PROVIN = New DevExpress.XtraReports.UI.XRLabel()
        Me.DOMICILIO = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel19 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel18 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel17 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel16 = New DevExpress.XtraReports.UI.XRLabel()
        Me.NOM_PROVEE = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel14 = New DevExpress.XtraReports.UI.XRLabel()
        Me.FECHA_EMIS = New DevExpress.XtraReports.UI.XRLabel()
        Me.N_COMP = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel11 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel10 = New DevExpress.XtraReports.UI.XRLabel()
        Me.N_CERTIFIC = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel8 = New DevExpress.XtraReports.UI.XRLabel()
        Me.Impuesto = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel6 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel5 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel4 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel3 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel2 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel1 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel26 = New DevExpress.XtraReports.UI.XRLabel()
        Me.fooCertificado = New DevExpress.XtraReports.UI.GroupFooterBand()
        Me.XrLine1 = New DevExpress.XtraReports.UI.XRLine()
        Me.XrLabel28 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrLabel29 = New DevExpress.XtraReports.UI.XRLabel()
        Me.XrPictureBox1 = New DevExpress.XtraReports.UI.XRPictureBox()
        CType(Me, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'Detail
        '
        Me.Detail.HeightF = 1.041667!
        Me.Detail.Name = "Detail"
        Me.Detail.Padding = New DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100.0!)
        Me.Detail.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft
        '
        'TopMargin
        '
        Me.TopMargin.HeightF = 14.58333!
        Me.TopMargin.Name = "TopMargin"
        Me.TopMargin.Padding = New DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100.0!)
        Me.TopMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft
        '
        'BottomMargin
        '
        Me.BottomMargin.HeightF = 21.875!
        Me.BottomMargin.Name = "BottomMargin"
        Me.BottomMargin.Padding = New DevExpress.XtraPrinting.PaddingInfo(0, 0, 0, 0, 100.0!)
        Me.BottomMargin.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopLeft
        '
        'grpCertificado
        '
        Me.grpCertificado.Controls.AddRange(New DevExpress.XtraReports.UI.XRControl() {Me.XrLine1, Me.XrLabel28, Me.XrLabel29, Me.XrPictureBox1, Me.PORCE_RET, Me.IMP_RETEN, Me.XrLabel27, Me.XrLabel25, Me.XrLabel24, Me.N_ING_BRUT, Me.N_CUIT, Me.NOM_PROVIN, Me.DOMICILIO, Me.XrLabel19, Me.XrLabel18, Me.XrLabel17, Me.XrLabel16, Me.NOM_PROVEE, Me.XrLabel14, Me.FECHA_EMIS, Me.N_COMP, Me.XrLabel11, Me.XrLabel10, Me.N_CERTIFIC, Me.XrLabel8, Me.Impuesto, Me.XrLabel6, Me.XrLabel5, Me.XrLabel4, Me.XrLabel3, Me.XrLabel2, Me.XrLabel1, Me.XrLabel26})
        Me.grpCertificado.HeightF = 796.875!
        Me.grpCertificado.Name = "grpCertificado"
        '
        'PORCE_RET
        '
        Me.PORCE_RET.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PORCE_RET.LocationFloat = New DevExpress.Utils.PointFloat(281.6669!, 553.1251!)
        Me.PORCE_RET.Name = "PORCE_RET"
        Me.PORCE_RET.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.PORCE_RET.SizeF = New System.Drawing.SizeF(358.3331!, 23.95831!)
        Me.PORCE_RET.StylePriority.UseFont = False
        Me.PORCE_RET.Text = "PORCE_RET"
        '
        'IMP_RETEN
        '
        Me.IMP_RETEN.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IMP_RETEN.LocationFloat = New DevExpress.Utils.PointFloat(281.6665!, 529.1667!)
        Me.IMP_RETEN.Name = "IMP_RETEN"
        Me.IMP_RETEN.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.IMP_RETEN.SizeF = New System.Drawing.SizeF(358.3331!, 23.95831!)
        Me.IMP_RETEN.StylePriority.UseFont = False
        Me.IMP_RETEN.Text = "IMP_RETEN"
        '
        'XrLabel27
        '
        Me.XrLabel27.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel27.LocationFloat = New DevExpress.Utils.PointFloat(10.00013!, 628.5416!)
        Me.XrLabel27.Name = "XrLabel27"
        Me.XrLabel27.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel27.SizeF = New System.Drawing.SizeF(417.4999!, 23.95831!)
        Me.XrLabel27.StylePriority.UseFont = False
        Me.XrLabel27.Text = "Por Agrupación de Colaboración Grupo Paramedic"
        '
        'XrLabel25
        '
        Me.XrLabel25.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel25.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 553.125!)
        Me.XrLabel25.Name = "XrLabel25"
        Me.XrLabel25.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel25.SizeF = New System.Drawing.SizeF(271.6665!, 23.95834!)
        Me.XrLabel25.StylePriority.UseFont = False
        Me.XrLabel25.Text = "Alicuota Aplicada"
        '
        'XrLabel24
        '
        Me.XrLabel24.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel24.LocationFloat = New DevExpress.Utils.PointFloat(10.00013!, 529.1667!)
        Me.XrLabel24.Name = "XrLabel24"
        Me.XrLabel24.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel24.SizeF = New System.Drawing.SizeF(271.6665!, 23.95834!)
        Me.XrLabel24.StylePriority.UseFont = False
        Me.XrLabel24.Text = "Importe Retenido"
        '
        'N_ING_BRUT
        '
        Me.N_ING_BRUT.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.N_ING_BRUT.LocationFloat = New DevExpress.Utils.PointFloat(281.6666!, 462.5!)
        Me.N_ING_BRUT.Name = "N_ING_BRUT"
        Me.N_ING_BRUT.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.N_ING_BRUT.SizeF = New System.Drawing.SizeF(358.3331!, 23.95831!)
        Me.N_ING_BRUT.StylePriority.UseFont = False
        Me.N_ING_BRUT.Text = "N_ING_BRUT"
        '
        'N_CUIT
        '
        Me.N_CUIT.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.N_CUIT.LocationFloat = New DevExpress.Utils.PointFloat(281.6669!, 438.5417!)
        Me.N_CUIT.Name = "N_CUIT"
        Me.N_CUIT.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.N_CUIT.SizeF = New System.Drawing.SizeF(358.3331!, 23.95831!)
        Me.N_CUIT.StylePriority.UseFont = False
        Me.N_CUIT.Text = "N_CUIT"
        '
        'NOM_PROVIN
        '
        Me.NOM_PROVIN.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NOM_PROVIN.LocationFloat = New DevExpress.Utils.PointFloat(281.6666!, 414.5834!)
        Me.NOM_PROVIN.Name = "NOM_PROVIN"
        Me.NOM_PROVIN.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.NOM_PROVIN.SizeF = New System.Drawing.SizeF(358.3331!, 23.95831!)
        Me.NOM_PROVIN.StylePriority.UseFont = False
        Me.NOM_PROVIN.Text = "NOM_PROVIN"
        '
        'DOMICILIO
        '
        Me.DOMICILIO.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DOMICILIO.LocationFloat = New DevExpress.Utils.PointFloat(281.6666!, 390.625!)
        Me.DOMICILIO.Name = "DOMICILIO"
        Me.DOMICILIO.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.DOMICILIO.SizeF = New System.Drawing.SizeF(358.3331!, 23.95831!)
        Me.DOMICILIO.StylePriority.UseFont = False
        Me.DOMICILIO.Text = "DOMICILIO"
        '
        'XrLabel19
        '
        Me.XrLabel19.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel19.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 462.5!)
        Me.XrLabel19.Name = "XrLabel19"
        Me.XrLabel19.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel19.SizeF = New System.Drawing.SizeF(271.6665!, 23.95834!)
        Me.XrLabel19.StylePriority.UseFont = False
        Me.XrLabel19.Text = "Nro. Ingresos Brutos"
        '
        'XrLabel18
        '
        Me.XrLabel18.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel18.LocationFloat = New DevExpress.Utils.PointFloat(10.00013!, 438.5417!)
        Me.XrLabel18.Name = "XrLabel18"
        Me.XrLabel18.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel18.SizeF = New System.Drawing.SizeF(271.6665!, 23.95834!)
        Me.XrLabel18.StylePriority.UseFont = False
        Me.XrLabel18.Text = "Nro. CUIT"
        '
        'XrLabel17
        '
        Me.XrLabel17.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel17.LocationFloat = New DevExpress.Utils.PointFloat(10.00013!, 414.5833!)
        Me.XrLabel17.Name = "XrLabel17"
        Me.XrLabel17.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel17.SizeF = New System.Drawing.SizeF(271.6665!, 23.95834!)
        Me.XrLabel17.StylePriority.UseFont = False
        Me.XrLabel17.Text = "Provincia"
        '
        'XrLabel16
        '
        Me.XrLabel16.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel16.LocationFloat = New DevExpress.Utils.PointFloat(10.00013!, 390.625!)
        Me.XrLabel16.Name = "XrLabel16"
        Me.XrLabel16.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel16.SizeF = New System.Drawing.SizeF(271.6665!, 23.95834!)
        Me.XrLabel16.StylePriority.UseFont = False
        Me.XrLabel16.Text = "Domicilio"
        '
        'NOM_PROVEE
        '
        Me.NOM_PROVEE.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NOM_PROVEE.LocationFloat = New DevExpress.Utils.PointFloat(281.6666!, 366.6667!)
        Me.NOM_PROVEE.Name = "NOM_PROVEE"
        Me.NOM_PROVEE.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.NOM_PROVEE.SizeF = New System.Drawing.SizeF(358.3332!, 23.95834!)
        Me.NOM_PROVEE.StylePriority.UseFont = False
        Me.NOM_PROVEE.Text = "NOM_PROVEE"
        '
        'XrLabel14
        '
        Me.XrLabel14.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel14.LocationFloat = New DevExpress.Utils.PointFloat(10.00013!, 366.6667!)
        Me.XrLabel14.Name = "XrLabel14"
        Me.XrLabel14.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel14.SizeF = New System.Drawing.SizeF(271.6665!, 23.95834!)
        Me.XrLabel14.StylePriority.UseFont = False
        Me.XrLabel14.Text = "Apellido y Nombre o Razón Social"
        '
        'FECHA_EMIS
        '
        Me.FECHA_EMIS.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FECHA_EMIS.LocationFloat = New DevExpress.Utils.PointFloat(332.7082!, 303.1249!)
        Me.FECHA_EMIS.Name = "FECHA_EMIS"
        Me.FECHA_EMIS.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.FECHA_EMIS.SizeF = New System.Drawing.SizeF(129.9999!, 23.95833!)
        Me.FECHA_EMIS.StylePriority.UseFont = False
        Me.FECHA_EMIS.Text = "FECHA_EMIS"
        '
        'N_COMP
        '
        Me.N_COMP.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.N_COMP.LocationFloat = New DevExpress.Utils.PointFloat(332.7082!, 279.1666!)
        Me.N_COMP.Name = "N_COMP"
        Me.N_COMP.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.N_COMP.SizeF = New System.Drawing.SizeF(129.9999!, 23.95833!)
        Me.N_COMP.StylePriority.UseFont = False
        Me.N_COMP.Text = "N_COMP"
        '
        'XrLabel11
        '
        Me.XrLabel11.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel11.LocationFloat = New DevExpress.Utils.PointFloat(170.4167!, 303.1249!)
        Me.XrLabel11.Name = "XrLabel11"
        Me.XrLabel11.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel11.SizeF = New System.Drawing.SizeF(162.2915!, 23.95831!)
        Me.XrLabel11.StylePriority.UseFont = False
        Me.XrLabel11.Text = "Fecha:"
        '
        'XrLabel10
        '
        Me.XrLabel10.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel10.LocationFloat = New DevExpress.Utils.PointFloat(170.4167!, 279.1666!)
        Me.XrLabel10.Name = "XrLabel10"
        Me.XrLabel10.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel10.SizeF = New System.Drawing.SizeF(162.2915!, 23.95831!)
        Me.XrLabel10.StylePriority.UseFont = False
        Me.XrLabel10.Text = "Nro. de Orden de Pago:"
        '
        'N_CERTIFIC
        '
        Me.N_CERTIFIC.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.N_CERTIFIC.LocationFloat = New DevExpress.Utils.PointFloat(332.7082!, 255.2083!)
        Me.N_CERTIFIC.Name = "N_CERTIFIC"
        Me.N_CERTIFIC.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.N_CERTIFIC.SizeF = New System.Drawing.SizeF(129.9999!, 23.95833!)
        Me.N_CERTIFIC.StylePriority.UseFont = False
        Me.N_CERTIFIC.Text = "N_CERTIFIC"
        '
        'XrLabel8
        '
        Me.XrLabel8.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel8.LocationFloat = New DevExpress.Utils.PointFloat(170.4167!, 255.2083!)
        Me.XrLabel8.Name = "XrLabel8"
        Me.XrLabel8.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel8.SizeF = New System.Drawing.SizeF(162.2915!, 23.95833!)
        Me.XrLabel8.StylePriority.UseFont = False
        Me.XrLabel8.Text = "Nro. Certificado:"
        '
        'Impuesto
        '
        Me.Impuesto.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Impuesto.LocationFloat = New DevExpress.Utils.PointFloat(10.00013!, 206.6667!)
        Me.Impuesto.Name = "Impuesto"
        Me.Impuesto.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.Impuesto.SizeF = New System.Drawing.SizeF(629.9999!, 23.95833!)
        Me.Impuesto.StylePriority.UseFont = False
        Me.Impuesto.Text = "Comprobante de Retención IIBB Pcia. Bs.As."
        '
        'XrLabel6
        '
        Me.XrLabel6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel6.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 154.1667!)
        Me.XrLabel6.Name = "XrLabel6"
        Me.XrLabel6.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel6.SizeF = New System.Drawing.SizeF(629.9999!, 23.95833!)
        Me.XrLabel6.StylePriority.UseFont = False
        Me.XrLabel6.Text = "Nro. de Agente: ACE"
        '
        'XrLabel5
        '
        Me.XrLabel5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel5.LocationFloat = New DevExpress.Utils.PointFloat(10.00013!, 130.2083!)
        Me.XrLabel5.Name = "XrLabel5"
        Me.XrLabel5.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel5.SizeF = New System.Drawing.SizeF(629.9999!, 23.95833!)
        Me.XrLabel5.StylePriority.UseFont = False
        Me.XrLabel5.Text = "Ingresos Brutos: 901-067572-3"
        '
        'XrLabel4
        '
        Me.XrLabel4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel4.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 106.25!)
        Me.XrLabel4.Name = "XrLabel4"
        Me.XrLabel4.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel4.SizeF = New System.Drawing.SizeF(629.9999!, 23.95833!)
        Me.XrLabel4.StylePriority.UseFont = False
        Me.XrLabel4.Text = "C.U.I.T.: 30-70835813-0"
        '
        'XrLabel3
        '
        Me.XrLabel3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel3.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 66.04166!)
        Me.XrLabel3.Name = "XrLabel3"
        Me.XrLabel3.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel3.SizeF = New System.Drawing.SizeF(629.9999!, 23.95833!)
        Me.XrLabel3.StylePriority.UseFont = False
        Me.XrLabel3.Text = "CAPITAL FEDERAL"
        '
        'XrLabel2
        '
        Me.XrLabel2.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel2.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 37.5!)
        Me.XrLabel2.Name = "XrLabel2"
        Me.XrLabel2.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel2.SizeF = New System.Drawing.SizeF(629.9999!, 23.95833!)
        Me.XrLabel2.StylePriority.UseFont = False
        Me.XrLabel2.Text = "DONADO 1748"
        '
        'XrLabel1
        '
        Me.XrLabel1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel1.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 10.00001!)
        Me.XrLabel1.Name = "XrLabel1"
        Me.XrLabel1.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel1.SizeF = New System.Drawing.SizeF(629.9999!, 23.95833!)
        Me.XrLabel1.StylePriority.UseFont = False
        Me.XrLabel1.Text = "AGRUPACIÓN DE COLABORACIÓN GRUPO PARAMEDIC"
        '
        'XrLabel26
        '
        Me.XrLabel26.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel26.LocationFloat = New DevExpress.Utils.PointFloat(10.00001!, 604.5833!)
        Me.XrLabel26.Name = "XrLabel26"
        Me.XrLabel26.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel26.SizeF = New System.Drawing.SizeF(271.6665!, 23.95834!)
        Me.XrLabel26.StylePriority.UseFont = False
        Me.XrLabel26.Text = "CAPITAL FEDERAL, 00/00/0000"
        '
        'fooCertificado
        '
        Me.fooCertificado.HeightF = 51.04167!
        Me.fooCertificado.Name = "fooCertificado"
        '
        'XrLine1
        '
        Me.XrLine1.LocationFloat = New DevExpress.Utils.PointFloat(431.25!, 735.8334!)
        Me.XrLine1.Name = "XrLine1"
        Me.XrLine1.SizeF = New System.Drawing.SizeF(195.8333!, 3.125!)
        '
        'XrLabel28
        '
        Me.XrLabel28.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel28.LocationFloat = New DevExpress.Utils.PointFloat(431.25!, 738.9584!)
        Me.XrLabel28.Name = "XrLabel28"
        Me.XrLabel28.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel28.SizeF = New System.Drawing.SizeF(195.8333!, 23.95831!)
        Me.XrLabel28.StylePriority.UseFont = False
        Me.XrLabel28.Text = "Eduardo Fabián Couma"
        '
        'XrLabel29
        '
        Me.XrLabel29.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XrLabel29.LocationFloat = New DevExpress.Utils.PointFloat(431.25!, 762.9167!)
        Me.XrLabel29.Name = "XrLabel29"
        Me.XrLabel29.Padding = New DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100.0!)
        Me.XrLabel29.SizeF = New System.Drawing.SizeF(195.8333!, 23.95831!)
        Me.XrLabel29.StylePriority.UseFont = False
        Me.XrLabel29.Text = "Administrador"
        '
        'XrPictureBox1
        '
        Me.XrPictureBox1.Image = CType(resources.GetObject("XrPictureBox1.Image"), System.Drawing.Image)
        Me.XrPictureBox1.LocationFloat = New DevExpress.Utils.PointFloat(456.25!, 668.1251!)
        Me.XrPictureBox1.Name = "XrPictureBox1"
        Me.XrPictureBox1.SizeF = New System.Drawing.SizeF(152.0833!, 67.70825!)
        '
        'repCertificadoIIBB
        '
        Me.Bands.AddRange(New DevExpress.XtraReports.UI.Band() {Me.Detail, Me.TopMargin, Me.BottomMargin, Me.grpCertificado, Me.fooCertificado})
        Me.Margins = New System.Drawing.Printing.Margins(100, 100, 15, 22)
        Me.Version = "14.2"
        CType(Me, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Friend WithEvents Detail As DevExpress.XtraReports.UI.DetailBand
    Friend WithEvents TopMargin As DevExpress.XtraReports.UI.TopMarginBand
    Friend WithEvents BottomMargin As DevExpress.XtraReports.UI.BottomMarginBand
    Friend WithEvents grpCertificado As DevExpress.XtraReports.UI.GroupHeaderBand
    Friend WithEvents fooCertificado As DevExpress.XtraReports.UI.GroupFooterBand
    Friend WithEvents PORCE_RET As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents IMP_RETEN As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel27 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel25 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel24 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents N_ING_BRUT As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents N_CUIT As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents NOM_PROVIN As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents DOMICILIO As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel19 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel18 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel17 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel16 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents NOM_PROVEE As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel14 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents FECHA_EMIS As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents N_COMP As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel11 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel10 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents N_CERTIFIC As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel8 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents Impuesto As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel6 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel5 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel4 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel3 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel2 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel1 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel26 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLine1 As DevExpress.XtraReports.UI.XRLine
    Friend WithEvents XrLabel28 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrLabel29 As DevExpress.XtraReports.UI.XRLabel
    Friend WithEvents XrPictureBox1 As DevExpress.XtraReports.UI.XRPictureBox
End Class
