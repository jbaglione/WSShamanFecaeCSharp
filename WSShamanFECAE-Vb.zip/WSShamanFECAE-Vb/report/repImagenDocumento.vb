﻿Public Class repImagenDocumento

End Class