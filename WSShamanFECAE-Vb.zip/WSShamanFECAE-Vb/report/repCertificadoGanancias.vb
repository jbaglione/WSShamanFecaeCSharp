﻿Public Class repCertificadoGanancias

End Class