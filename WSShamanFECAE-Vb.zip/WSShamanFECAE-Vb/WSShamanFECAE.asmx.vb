﻿Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Xml
Imports ShamanClases
Imports DevExpress.XtraReports.UI
Imports System.Web.Configuration

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class WSShamanFECAE
    Inherits System.Web.Services.WebService

    Public Enum Certificado As Integer
        crtArba = 0
        crtAgip = 1
        crtGanancias = 2
        crtIVA = 3
        crtCajaPrevisional = 4
    End Enum

    <WebMethod()> _
    Public Function GetPDF_Cache(pDocId As Decimal, pUsrId As Decimal) As Byte()

        Dim objConexion As New PanelC.Conexion

        Dim vRet As System.IO.MemoryStream = Nothing

        If objConexion.Iniciar(My.Resources.cacheServer, CInt(My.Resources.cachePort), My.Resources.cacheNameSpace, My.Resources.cacheShamanAplicacion, _
                               My.Resources.cacheShamanUser, CInt(My.Resources.cacheShamanCentro), True) Then

            '----> Obtengo documento
            Dim objComprobante As New VentasC.ClientesDocumentos
            Dim vDataView As New DataView
            Dim vStream As New System.IO.MemoryStream

            If objComprobante.prepareToPrint(objConexion.PID, pDocId, vDataView, vStream) Then

                Dim objReport As New repImagenDocumento

                objReport.DataSource = vDataView
                objReport.LoadLayout(vStream)

                vRet = New System.IO.MemoryStream

                objReport.ExportToPdf(vRet)

                '----> Marco descarga
                Dim objMarcas As New VentasC.CliDocAutomatizacion

                objMarcas.SetAutomatizacion(pDocId, hCliDocAutomatizacion.hDownload, 1, pUsrId, HttpContext.Current.Request.UserHostAddress, "JOB")

            End If

            objComprobante = Nothing

            objConexion.Cerrar(objConexion.PID)

        End If

        objConexion = Nothing

        If Not vRet Is Nothing Then
            Return vRet.ToArray()
        Else
            Return Nothing
        End If

    End Function

    <WebMethod()> _
    Public Function GetReportsIncidente_Cache(pInc As Decimal, pUsrId As Decimal) As Byte()

        Dim objConexion As New PanelC.Conexion

        Dim vRet As System.IO.MemoryStream = Nothing

        If objConexion.Iniciar(My.Resources.cacheServer, CInt(My.Resources.cachePort), My.Resources.cacheNameSpace, My.Resources.cacheShamanAplicacion, _
                               My.Resources.cacheShamanUser, CInt(My.Resources.cacheShamanCentro), True) Then

            '----> Obtengo documento
            Dim objOrdenes As New VentasC.IncOrdenesControl

            Dim dtOrds As DataTable = objOrdenes.GetOrdenesIncidente(pInc)

            objOrdenes = Nothing

            objConexion.Cerrar(objConexion.PID)

        End If

        objConexion = Nothing

        If Not vRet Is Nothing Then
            Return vRet.ToArray()
        Else
            Return Nothing
        End If

    End Function

    <WebMethod()> _
    Public Function GetCuentaCorriene(pUsr As Decimal) As DataTable

        Dim objConexion As New PanelC.Conexion

        '---> Conecto a Cache

        If objConexion.Iniciar(My.Resources.cacheServer, CInt(My.Resources.cachePort), My.Resources.cacheNameSpace, My.Resources.cacheShamanAplicacion, _
                       My.Resources.cacheShamanUser, CInt(My.Resources.cacheShamanCentro), True) Then

            '---> Conecto a Tango

            Dim objTango As New VentasC.Tango

            Dim cnn As SqlConnection = objTango.UpTangoEngine(Val(My.Resources.tangoEmpresaId))

            If Not cnn Is Nothing Then

                '-----> Obengo lista de proveedores
                Dim objProveedores As New VentasC.ProveedoresDocumentos
                Dim dtPrv As DataTable = objProveedores.GetProveedoresByUsuarioExtranet(pUsr)

                If dtPrv.Rows.Count > 0 Then

                    Dim dtOps As DataTable = objTango.GetOPs(cnn, dtPrv)
                    Dim vPreId As Decimal = objProveedores.GetPrestadorIdByUsuarioExtranet(pUsr)
                    Dim vMedId As String = objProveedores.GetMedicoIdByUsuarioExtranet(pUsr)

                    Dim vIdx As Integer

                    dtOps.Columns("Referencias").ReadOnly = False
                    dtOps.Columns("TipoComprobante").ReadOnly = False
                    dtOps.Columns("NroComprobante").ReadOnly = False

                    '-----> Establezco referencias de liquidación
                    For vIdx = 0 To dtOps.Rows.Count - 1

                        dtOps.Rows(vIdx)("Referencias") = objProveedores.GetReferenciasOP(vPreId, vMedId, dtOps.Rows(vIdx)("NroOrdenPago"))
                        If IsDBNull(dtOps.Rows(vIdx)("TipoComprobante")) Then dtOps.Rows(vIdx)("TipoComprobante") = ""
                        If IsDBNull(dtOps.Rows(vIdx)("NroComprobante")) Then dtOps.Rows(vIdx)("NroComprobante") = ""

                        If dtOps.Rows(vIdx)("TipoComprobante") = "" And dtOps.Rows(vIdx)("NroComprobante") = "" Then

                            Dim dtDocs As DataTable = objProveedores.GetComprobantesOrdenesPago(dtOps.Rows(vIdx)("NroOrdenPago"), dtOps.Rows(vIdx)("TipoComprobante"), dtOps.Rows(vIdx)("NroComprobante"))
                            Dim vDocIdx As Integer

                            For vDocIdx = 0 To dtDocs.Rows.Count - 1
                                If vDocIdx = 0 Then
                                    dtOps.Rows(vIdx)("TipoComprobante") = dtDocs.Rows(vDocIdx)("TipoComprobante")
                                    dtOps.Rows(vIdx)("NroComprobante") = dtDocs.Rows(vDocIdx)("NroComprobante")
                                Else
                                    Dim dtRow As DataRow = dtOps.NewRow
                                    Dim vCol As Integer
                                    For vCol = 0 To dtOps.Columns.Count - 1
                                        dtRow(vCol) = dtOps.Rows(vIdx)(vCol)
                                    Next
                                    dtRow("TipoComprobante") = dtDocs.Rows(vDocIdx)("TipoComprobante")
                                    dtRow("NroComprobante") = dtDocs.Rows(vDocIdx)("NroComprobante")
                                    dtOps.Rows.Add(dtRow)
                                End If
                            Next vDocIdx

                        End If

                    Next

                    cnn.Close()
                    objConexion.Cerrar(objConexion.PID, True)

                    dtOps.TableName = "OrdenesPago"
                    Dim dtView As New DataView(dtOps)
                    dtView.Sort = "NroOrdenPago DESC, TipoComprobante, NroComprobante"

                    Return dtView.ToTable

                Else

                    Return Nothing

                End If

            Else

                Return Nothing

            End If

        Else

            Return Nothing
        End If

    End Function


    <WebMethod()> _
    Public Function GetCertificadoRetencion_Tango(pNroOp As String, pRetId As Certificado) As Byte()

        Dim objConexion As New PanelC.Conexion

        '---> Conecto a Cache

        If objConexion.Iniciar(WebConfigurationManager.AppSettings.Get("cacheServer"), CInt(WebConfigurationManager.AppSettings.Get("cachePort")), WebConfigurationManager.AppSettings.Get("cacheNameSpace"), _
                               WebConfigurationManager.AppSettings.Get("cacheShamanAplicacion"), WebConfigurationManager.AppSettings.Get("cacheShamanUser"), _
                               CInt(WebConfigurationManager.AppSettings.Get("cacheShamanCentro")), True) Then

            Dim objTango As New VentasC.Tango
            Dim vRet As System.IO.MemoryStream = Nothing

            Dim cnn As SqlConnection = objTango.UpTangoEngine(Val(My.Resources.tangoEmpresaId), False)

            If Not cnn Is Nothing Then

                Dim dt As DataTable

                Select Case pRetId

                    Case Certificado.crtArba

                        dt = objTango.GetCertificadoRetencion(cnn, pNroOp, VentasC.Tango.Certificado.crtArba)

                        Dim objReport As New repCertificadoIIBB

                        objReport.DataSource = New DataView(dt)

                        BindSection(objReport.grpCertificado, objReport.DataSource)
                        objReport.Impuesto.Text = "Comprobante de Retención IIBB Pcia. Bs.As."

                        vRet = New System.IO.MemoryStream

                        objReport.ExportToPdf(vRet)

                    Case Certificado.crtAgip

                        dt = objTango.GetCertificadoRetencion(cnn, pNroOp, VentasC.Tango.Certificado.crtAgip)

                        Dim objReport As New repCertificadoIIBB

                        objReport.DataSource = New DataView(dt)

                        BindSection(objReport.grpCertificado, objReport.DataSource)
                        objReport.Impuesto.Text = "Comprobante de Retención IIBB Ciudad de Bs. As."

                        vRet = New System.IO.MemoryStream

                        objReport.ExportToPdf(vRet)

                    Case Certificado.crtGanancias

                        dt = objTango.GetCertificadoRetencion(cnn, pNroOp, VentasC.Tango.Certificado.crtGanancias)

                        Dim objReport As New repCertificadoGanancias

                        objReport.DataSource = New DataView(dt)

                        BindSection(objReport.grpCertificado, objReport.DataSource)
                        objReport.Impuesto.Text = "Comprobante de Retención de Ganancias"

                        vRet = New System.IO.MemoryStream

                        objReport.ExportToPdf(vRet)

                    Case Certificado.crtIVA

                        dt = objTango.GetCertificadoRetencion(cnn, pNroOp, VentasC.Tango.Certificado.crtIVA)

                        Dim objReport As New repCertificadoGanancias

                        objReport.DataSource = New DataView(dt)

                        BindSection(objReport.grpCertificado, objReport.DataSource)
                        objReport.Impuesto.Text = "Comprobante de Retención de IVA"

                        vRet = New System.IO.MemoryStream

                        objReport.ExportToPdf(vRet)

                    Case Certificado.crtCajaPrevisional

                        dt = objTango.GetCertificadoCajaPrevisional(cnn, pNroOp)

                        Dim objReport As New repCertificadoCaja

                        objReport.DataSource = New DataView(dt)

                        BindSection(objReport.grpCertificado, objReport.DataSource)

                        vRet = New System.IO.MemoryStream

                        objReport.ExportToPdf(vRet)

                End Select

                cnn.Close()
                objConexion.Cerrar(objConexion.PID, True)

                If Not vRet Is Nothing Then

                    Return vRet.ToArray()

                Else
                    Return System.Text.Encoding.Unicode.GetBytes("No pudo armarse el PDF")
                End If

            Else

                Return System.Text.Encoding.Unicode.GetBytes("No hay conexión a Tango")

            End If

        Else

            Return System.Text.Encoding.Unicode.GetBytes("No hay conexión a Cache")

        End If

    End Function

    Private Sub BindSection(pBand As Band, pSou As Object)
        Dim xr As XRControl

        For Each xr In pBand.Controls

            If xr.GetType.Name = "XRLabel" Then
                If xr.Name.Substring(0, 2).ToLower <> "xr" Then
                    xr.DataBindings.Add("Text", pSou, xr.Name)
                End If
            End If
        Next

    End Sub

End Class